<h1><?= $page->title() ?></h1>
